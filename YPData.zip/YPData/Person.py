#!/usr/bin/python
# -*- coding: UTF-8 -*-

class Person:

    def __init__(self, name, phone, orderstatus, ordertime):
        self.name = name
        self.phone = phone
        self.orderstatus = orderstatus
        self.ordertime = ordertime

    
